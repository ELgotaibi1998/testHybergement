const { recognize } = require("tesseract.js");
const t=require("tesseract.js");
t.recognize("/images/usmba.png","fr")