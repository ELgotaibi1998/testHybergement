
<?php $__env->startSection("content"); ?>
<div class="container">
      <div>
          Categorie : <select name="categorie" id="categorie"  required>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->categorie); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            Emplacement : <select name="emplacement" id="emplacement" required>
              <?php $__currentLoopData = $emplacements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lieu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($lieu->id); ?>"><?php echo e($lieu->emplacement); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            Reference : <input type="text" name="reference" id="reference">
            Désignation : <input type="text" name="designation" id="designation">
            <button id='btn' onclick="f()" class="btn btn-primary"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-search" viewBox="0 0 16 16">
              <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z"/>
            </svg></button>
      </div><br><hr>
      <div id="listArticle"></div>
</div>
<?php $__env->stopSection(); ?>
<script>
  function f(params) {
    let categorie=document.getElementById("categorie").value;
    let emplacement=document.getElementById("emplacement").value;
    let reference=document.getElementById("reference").value;
    let designation=document.getElementById("designation").value;
    let xhr=new XMLHttpRequest();
    xhr.open("GET","/getArticles?categorie="+categorie+"&emplacement="+emplacement+"&reference="+reference+"&designation="+designation);
    xhr.send();
    xhr.onreadystatechange=function(){
      if(xhr.status==200 && xhr.readyState==4){
      let articles=xhr.responseText ;
        document.getElementById("listArticle").innerHTML= articles;
      }
    }
 }
 </script>
<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Akay\Documents\insa\gestionStock\resources\views/articles/search.blade.php ENDPATH**/ ?>