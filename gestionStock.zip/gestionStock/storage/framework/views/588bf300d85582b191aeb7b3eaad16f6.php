
<?php $__env->startSection("content"); ?>
<div >
  <br>
<u><h1>Modifier un Personne</h1></u> 
 <br>
 <form action="<?php echo e(route('personnes.update',['personne'=>$prs['id']])); ?>" method="post">
    <?php echo method_field("put"); ?>
    <?php echo csrf_field(); ?>
   <table class="table">
   <tr><td>Nom : </td> <td><input type="text" name="nom" value="<?php echo e($prs->nom); ?>"></td> </tr>
       <tr><td>Service : </td> <td><input type="text" name="service" value="<?php echo e($prs->service); ?>"></td> </tr>
       <tr> <td><a class="btn btn-secondary" href="<?php echo e(route('personnes.index')); ?>">Retour</a>  </td> <td></td>
  <td> <button  class="btn btn-success"> Modifier</button></td></tr>
</table>

</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Akay\Documents\insa\gestionStock\resources\views/Personne/edit.blade.php ENDPATH**/ ?>