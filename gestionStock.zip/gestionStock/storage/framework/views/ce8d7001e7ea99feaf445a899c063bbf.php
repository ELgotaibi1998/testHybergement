
<?php $__env->startSection("content"); ?>
<div class="container">
 <h1>Decision de Radiation</h1>
       <hr >
       <form action="<?php echo e(route("radiats.store")); ?>" method="post" >
        <?php echo csrf_field(); ?>
          <table class="table">
          <tr><td>l'article</td> <td><input type="text"  readonly value="<?php echo e($article->designation); ?>"><input type="hidden" name="article" readonly value="<?php echo e($article->id); ?>"></td> </tr>
          <tr><td>Date Radiat</td> <td><input type="datetime-local" name="dateRadiat" required></td> </tr>
         
          <tr><td>Motif</td> <td><input type="text" name="motif" required></td> </tr>
        
          <tr ><td></td><td><input type="submit"  class="btn btn-danger" value="Supprimer l'article"></td> </tr>
          </table>
        </form>
        <a href="<?php echo e(route('articles.index')); ?>" class="btn btn-primary" >Retour</a>
</div>
   
    
<?php $__env->stopSection(); ?>
<style>
  input{
    width: 100%
  }
  select{
    width: 100%
  }
</style>
<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Akay\Documents\insa\gestionStock\resources\views/radiat/create.blade.php ENDPATH**/ ?>