
<?php $__env->startSection("content"); ?>
<div class="container"><br>
  <u>
 <h1> la demande de M <?php echo e($demande->users()->withTrashed()->get()[0]->name); ?></h1><br>
  </u>
         <table class="table"> 
          <tr><td> Pour 
            <?php if($demande->salle_id!=null): ?>
              la Salle : <?php echo e($demande->salles()->withTrashed()->get()[0]->nom); ?>

            <?php else: ?>
            le Personnel : <?php echo e($demande->personnes()->withTrashed()->get()[0]->nom); ?>

            <?php endif; ?> </td></tr>
      <tr><td>date de demande : <?php echo e($demande->dateDemande); ?> </td> </tr>
        <tr><td>l ' article : <?php echo e($demande->articles()->withTrashed()->get()[0]->designation); ?></td> </tr>
         
        <tr><td>Quantité : <?php echo e($demande->qteArticle); ?>  <?php echo e($demande->unites()->withTrashed()->get()[0]->unite); ?></td> 
          </tr> 
       </table>
</div>

<?php $__env->stopSection(); ?>
 <style>
  select{
    width: 100%
  }
 td input{
    width: 100%
  }
</style>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Akay\Documents\insa\gestionStock\resources\views/demandes/show.blade.php ENDPATH**/ ?>