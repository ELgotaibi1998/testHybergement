<?php  use App\Models\user ;
use App\Models\Article ;
use App\Models\Salle ;
use App\Models\Personne ;
?>

<?php $__env->startSection('content'); ?> <br>
   <u><h1>Notifications</h1></u> <br>
   
    <table class="table"   >
        <?php $__currentLoopData = auth()->user()->notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($n->read_at==null): ?>
                      <?php if(isset($n->data['article']) ): ?>
                        <tr><td style="background-color: rgb(171, 171, 189)"><form action="<?php echo e(route("notifications.update",['notification'=>$n->id])); ?>" method="post"><?php echo csrf_field(); ?> <?php echo method_field("put"); ?>
                          <a class="dropdown-item" href="<?php echo e(route('articles.show',['article'=>$n->data['article_id']])); ?>"> <?php echo e("L'article ".$n->data['article']." a une quantité de ".$n->data['qteStock']); ?> | <button>ok</button> </a></form></td></tr>
                      <?php else: ?>
                        <tr><td style="background-color: rgb(171, 171, 189)"><form action="<?php echo e(route("notifications.update",['notification'=>$n->id])); ?>" method="post"><?php echo csrf_field(); ?> <?php echo method_field("put"); ?>
                          <a class="dropdown-item" href="<?php echo e(route('demandes.show',['demande'=>$n->data['demande_id']])); ?>"> 
                          <?php if( isset($n->data['demandeurS']) ): ?>
                          <?php echo e(User::withTrashed()->where("id",$n->data['user'])->get()[0]->name."  a demander  L'article ".Article::find($n->data['articleD'])->designation." pour  la salle ".Salle::find($n->data['demandeurS'])->nom); ?> 
                          <?php else: ?>
                          <?php echo e(User::withTrashed()->where("id",$n->data['user'])->get()[0]->name."  a demander  L'article ".Article::find($n->data['articleD'])->designation." pour  le personnel ".Personne::find($n->data['demandeurP'])->nom); ?> 
                          <?php endif; ?>
                        | <button>ok</button></form> </a></td></tr> 
                      <?php endif; ?>
        <?php else: ?>
                      <?php if(isset($n->data['article']) ): ?>
                        <tr><td > <a class="dropdown-item" href="<?php echo e(route('articles.show',['article'=>$n->data['article_id']])); ?>"> <?php echo e("L'article ".$n->data['article']." a une quantité de ".$n->data['qteStock']); ?> </a></td></tr> 
                      <?php else: ?>
                        <tr><td >
                          <a class="dropdown-item" href="<?php echo e(route('demandes.show',['demande'=>$n->data['demande_id']])); ?>"> 
                            <?php if( isset($n->data['demandeurS']) ): ?>
                            <?php echo e(User::withTrashed()->where("id",$n->data['user'])->get()[0]->name."  a demander  L'article ".Article::find($n->data['articleD'])->designation." pour  la salle ".Salle::find($n->data['demandeurS'])->nom); ?> 
                            <?php else: ?>
                            <?php echo e(User::withTrashed()->where("id",$n->data['user'])->get()[0]->name."  a demander  L'article ".Article::find($n->data['articleD'])->designation." pour  le personnel ".Personne::find($n->data['demandeurP'])->nom); ?> 
                            <?php endif; ?> 
                          </a>
                        </td></tr> 
                    <?php endif; ?>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Akay\Documents\insa\gestionStock\resources\views/not.blade.php ENDPATH**/ ?>