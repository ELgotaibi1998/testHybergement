
<?php $__env->startSection("content"); ?>
<div class="container"><br>
  <?php if( session("categorie")): ?>
  <div class="alert alert-success" role="alert">
   <?php echo e(session("categorie")); ?>

  </div>
  <?php endif; ?>
 <h1>liste des Catégories des Matériels</h1>
    <div style="display:flex;flex-wrap:wrap">
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $art): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(route('articles.index',['id'=>$art->id])); ?>">
          <div class="card" style="width: 18rem;">
        <div class="card-body">
          <h5 class="card-title"><?php echo e($art->categorie); ?></h5>
        </div>
      </div>
        </a>
    
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
   
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Akay\Documents\insa\gestionStock\resources\views/categories/index.blade.php ENDPATH**/ ?>