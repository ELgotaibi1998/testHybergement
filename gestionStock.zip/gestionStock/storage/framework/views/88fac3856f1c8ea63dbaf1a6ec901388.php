
<?php $__env->startSection("content"); ?>
<div class="container"><br>
 <h1>Détail  Matériel</h1>
       <hr >
          <table class="table">
            <tr><td>Catégorie</td> <td>
              <?php echo e($article->categorie->categorie); ?></td> </tr>
          <tr><td>Emplacement</td> <td><?php echo e($article->emplacement()->withTrashed()->get()[0]->emplacement); ?></td> </tr>
          <tr><td>Reference</td> <td><?php echo e($article->reference); ?></td> </tr>
          <tr><td>Designation</td> <td><?php echo e($article->designation); ?></td> </tr>
          <tr><td>Prix Unitaire</td> <td><?php echo e($article->pu." DH"); ?></td> </tr>
          <tr><td>Date d'ajout</td> <td><?php echo e($article->dateInscription); ?></td></tr>
         
          <tr><td>Quantité</td> <td><?php echo e($article->qteStock." ".$article->unite()->withTrashed()->get()[0]->unite); ?></td> </tr>
          <tr><td>Observations</td><td ><p ><?php echo e($article->observation); ?></p></td></tr>
           <tr><td>Stock minimal</td> <td><?php echo e($article->Stockmin." ".$article->unite()->withTrashed()->get()[0]->unite); ?></td >  <tr >
            <tr><td>Stock maximal</td> <td><?php echo e($article->stockMax." ".$article->unite()->withTrashed()->get()[0]->unite); ?></td >  <tr >
              <tr><td>Stock d'alert</td> <td><?php echo e($article->alert." ".$article->unite()->withTrashed()->get()[0]->unite); ?></td >  <tr >
                <tr><td>Stock minimal</td> <td><?php echo e($article->securite." ".$article->unite()->withTrashed()->get()[0]->unite); ?></td >  <tr >
          <tr><td>Images : </td> <td >
            <div style="display: flex;flex-wrap:wrap">
               <?php $__currentLoopData = $article->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div><img src=<?php echo e('/storage/'.$img->image); ?> alt="" width="20%">
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
           </td> </tr>
           <tr><td><a href="<?php echo e('https://www.bing.com/images/search?q=image+'.$article->designation.'&form=HDRSC4&first=1'); ?>">consulté</a></td></tr>
          <td><a href="<?php echo e(route('articles.index')); ?>" class="btn btn-secondary" >Retour</a></td> <td></td><td style="margin-right:50%">
              <a class="btn btn-danger" href="<?php echo e(route('radiats.create',['id'=>$article->id])); ?>"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash" viewBox="0 0 16 16">
                <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z"/>
                <path fill-rule="evenodd" d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z"/>
              </svg></a>
            </td> </tr>
          </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Akay\Documents\insa\gestionStock\resources\views/articles/show.blade.php ENDPATH**/ ?>