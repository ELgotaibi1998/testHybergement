
<?php $__env->startSection("content"); ?>
<div class="container">
<u><h1>Détail  Facture</h1></u>
<table class="table">
    <?php if($fact->bonCmd_id!=null ): ?>
    <tr id="test"><td>Bon de commande</td><td><input type="text" name="BonCmd" readonly value="<?php echo e($fact->bonCmd->numBonCmd); ?>"></td></td> </tr>
  <?php else: ?>
  <tr id="test"><td>Marché</td><td><input type="text" name="BonCmd" readonly value="<?php echo e($fact->marches->numMarche); ?>"></td></td> </tr>
      <?php endif; ?>
 
       <tr><td>dateCmd : </td> <td><input type="datetime-local" readonly name="dateCmd" value="<?php echo e($fact->dateCmd); ?>"></td> </tr>
       <tr><td>qte : </td> <td><input type="text" name="qte" readonly value="<?php echo e($fact->qte); ?>"></td> </tr>
       <tr><td>prixT : </td> <td><input type="text" name="prixt" readonly value="<?php echo e($fact->prixT); ?>"></td> </tr>
       <tr><td>tva : </td> <td><input type="text" name="tva" readonly value="<?php echo e($fact->tva); ?>"></td> </tr>
       <tr><td>prixTTC: </td> <td><input type="text" name="prixTTC" readonly value="<?php echo e($fact->prixTTC); ?>"></td> </tr>
      
       <tr><td>Fornisseur :</td> <td><input type="text" readonly value="<?php echo e($fact->fournisseurs->nom); ?>"></td></td> </tr>
          <tr><td>Article :</td> <td><input type="text" name="BonCmd" id="hh" onchange="f()" checked value="<?php echo e($fact->articles->designation); ?>"></td></td> </tr>
          <tr><td>signature : </td> <td><input type="text" name="signature" value="<?php echo e($fact->signature); ?>"></td> </tr>
        
  <tr> <td><a class="btn btn-secondary" href="<?php echo e(route('factures.index')); ?>">Retour</a><br><br>  </td> <td></td>
  </tr>
    </table>

</div>
<?php $__env->stopSection(); ?>
<style>
  select{
    width: 100%
  }
 td input{
    width: 100%
  }
</style>
<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Akay\Documents\insa\gestionStock\resources\views/Facture/show.blade.php ENDPATH**/ ?>