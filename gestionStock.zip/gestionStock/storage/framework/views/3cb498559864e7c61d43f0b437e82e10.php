
 <?php $__env->startSection('content'); ?>
 <br>
 <u><h3>Ajouter Emplacement</h3></u> <br>
<table class="table">
      
<form action="<?php echo e(route('emplacements.store')); ?>" method="post">
    <?php echo csrf_field(); ?>
       <tr><td>Emplacement : </td> <td><input type="test" name="emplacement"></td> </tr>
      
      
      
<tr> <td><a class="btn btn-secondary" href="<?php echo e(route('emplacements.index')); ?>">Retour</a><br><br> <td></td><td> <button  class="btn btn-success"> Enregister</button></td></tr>

</form>

    </table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Akay\Documents\insa\gestionStock\resources\views/emplacements/create.blade.php ENDPATH**/ ?>