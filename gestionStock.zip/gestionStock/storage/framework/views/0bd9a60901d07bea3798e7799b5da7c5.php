
<?php $__env->startSection("content"); ?>
<div class="container">
  <u>
 <h1>Ajouter une demande</h1>
  </u>
      <form action="<?php echo e(route('demandes.store')); ?>" method="post"><?php echo csrf_field(); ?>
     <h5> Pour une   <input type="radio" name="demandeur" value="personne" onchange="f()">Personne | <input id="p" type="radio" checked name="demandeur" onchange="f()" value="salle">Salle <br> <br>
      </h5>
      
         <table class="table">
          <tr> <td>Nom</td><td><div id="test">
        <select name="salle"  >
        <?php $__currentLoopData = $salles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unite): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($unite->id); ?>" <?php if(old("salle")==$unite->id): ?>
            selected
          <?php endif; ?>><?php echo e($unite->nom); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
      </div></td></tr>
        <tr><td>Designation</td> <td><input type="text" readonly value="<?php echo e($article->designation); ?>" ><input type="hidden" name="article"  value="<?php echo e($article->id); ?>" ></td> </tr>
         <tr><td>date de demande</td> <td><input type="datetime-local" name="dateD"  value="<?php echo e(old("dateD")); ?>" ></td> </tr>
        <tr><td>Quantité</td> <td><input type="text" name="qte" value="<?php echo e(old("qte")); ?>" ><span class="text-danger"> <?php $__errorArgs = ['qte'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <?php echo e($message); ?> 
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span> </td>
          </td> </tr><tr><td>Unité</td><td><input type="hidden" name="unite" readonly value="<?php echo e($article->unite()->withTrashed()->get()[0]->id); ?>" id="" /><input  readonly value="<?php echo e($article->unite()->withTrashed()->get()[0]->unite); ?>" id="" /></tr>
        <tr><td></td><td><input type="submit" value="Demander" class="btn btn-success"></td></tr>
       </table>
      </form>
</div>
   
    <script>
      //document.getElementsByName("demandeur")[0].addEventListener("change",f);
  function f() {
    let xhr=new XMLHttpRequest();
    if(document.getElementsByName("demandeur")[0].checked) {
    xhr.open("GET","/getD?demandeur=personne");
    xhr.send();
      xhr.onreadystatechange=function(){
      if(xhr.status==200 && xhr.readyState==4){
      let demandeur=JSON.parse(xhr.responseText)  ;
      let s="<select name='personne' >";
      for(let i=0;i<demandeur.length;i++){
        s+="<option value='"+demandeur[i].id+"' >"+demandeur[i].nom+"</option>";
      }
      s+="</select>";
        document.getElementById("test").innerHTML= s;
      }
    }
    }
     if(document.getElementsByName("demandeur")[1].checked) {
       xhr.open("GET","/getD?demandeur=salle");
    xhr.send();
    xhr.onreadystatechange=function(){
      if(xhr.status==200 && xhr.readyState==4){
        let demandeur=JSON.parse(xhr.responseText)  ;
      let s="<select name='salle' >";
      for(let i=0;i<demandeur.length;i++){
        s+="<option value='"+demandeur[i].id+"' >"+demandeur[i].nom+"</option>";
      }
      s+="</select>";
        document.getElementById("test").innerHTML= s;
      }
    }
    }
   
 }
 </script>
<?php $__env->stopSection(); ?>
 <style>
  select{
    width: 100%
  }
 td input{
    width: 100%
  }
</style>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Akay\Documents\insa\gestionStock\resources\views/demandes/create.blade.php ENDPATH**/ ?>