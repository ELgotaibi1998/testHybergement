<?php  use App\Models\user ;
use App\Models\Article ;
use App\Models\Salle ;
use App\Models\Personne ;
?>
<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title> Gestion de stock</title>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.bunny.net/css?family=Nunito" rel="stylesheet">
    <link rel = "icon" href ="/images/usmba.png" 
            type = "image/x-icon">
    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss', 'resources/js/app.js']); ?>
    <style>
      @media print{
       .btn{
          display:none;
       }   
      }
       
    .navbar ul li a{ 
        
        text-transform:uppercase;

    }
    #not{
      /* position: relative; */
      padding-left:-300px;
      margin-left:-300px; 
    }
     
   </style>
</head>
<body onresize="resiz()">
        <div class="">
            <nav class="navbar navbar-expand-md navbar-dark bg-dark shadow-sm "  >
                <div class="container">
                    <a class="navbar-brand" href="<?php echo e(url('/home')); ?>">
                        <img src="/images/usmba.png" alt="Accueil" width="40px">
                    </a>
                       
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                        <span class="navbar-toggler-icon"></span>
                    </button>
            
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <!-- Left Side Of Navbar -->
                        <div class="position-sticky pt-3">
                           
                          </div>
                        <ul class="navbar-nav me-auto">
                                <?php if(Auth::user() and Auth::user()->role=="admin"): ?>
                                <li class="nav-item dropdown">
                                  <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false" style="margin-left:10px;color:white ">   Ajouter  
                                  </a>
                                  <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                    <li><a class="dropdown-item" href="<?php echo e(route('categories.create')); ?>">Catégorie</a></li>
                                    <li><a class="dropdown-item" href="<?php echo e(route('articles.create')); ?>">Matériel</a></li>
                                    <li><a class="dropdown-item" href="<?php echo e(route('fournisseurs.create')); ?>">Fournisseur</a></li>
                                    <li><a class="dropdown-item" href="<?php echo e(route('affectations.create')); ?>">Affectation</a></li>
                                    <li><a class="dropdown-item" href="<?php echo e(route('factures.create')); ?>">Facture</a></li>
                                    <li><a class="dropdown-item" href="/facture ">Facture T</a></li>
                                  </ul>
                                </li>
                                <li class="nav-item dropdown">
                                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false" style="margin-left:10px;color:white ">   Catégories  
                                    </a>
                                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                      <?php $__currentLoopData = App\Models\Categorie::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                         <li><a class="dropdown-item" href="<?php echo e(route('articles.index',['id'=>$cat->id])); ?>"><?php echo e($cat->categorie); ?></a></li>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                     
                                    </ul>
                                  </li>
                                
                                <li class="nav-item dropdown">
                                  <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false" style="margin-left:10px;color:white ">   Matériel 
                                  </a>
                                  <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                    <li><a class="dropdown-item" href="<?php echo e(route('articles.index')); ?>"> Matériel</a></li>
                                    <li><a class="dropdown-item" href="<?php echo e(route('radiats.index')); ?>">Radiats</a></li>
                                    
                                  </ul>
                                </li>
                                <li class="nav-item dropdown">
                                  <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false" style="margin-left:10px;color:white "> Factures
                                  </a>
                                  <ul class="dropdown-menu" aria-labelledby="navbarDropdown"> 
                                    <li><a class="dropdown-item" href="<?php echo e(route('bonCmds.index')); ?>">Consulter les Bon de commandes</a></li>
                                    <li><a class="dropdown-item" href="<?php echo e(route('marches.index')); ?>">Consulter les Marchés</a></li>
                                    <li><a class="dropdown-item" href="<?php echo e(route('fournisseurs.index')); ?>">Consulter les Fournisseur</a></li>
                                  </ul>
                                </li>
                                <li class="nav-item">
                                  <a class="nav-link active" style="display:flex " aria-current="page" href="<?php echo e(route("mouvements.index")); ?>">  <p style="margin-left:10px ">Mouvements</p>   
                                    </a>
                              </li>
                               
                                <li class="nav-item">
                                  <a class="nav-link active" style="display:flex " aria-current="page" href="<?php echo e(route("affectations.index")); ?>">  <p style="margin-left:10px ">Affectation</p>    
                                    </a>
                              </li>
                              <li class="nav-item ">
                                <a class="nav-link active" style="display:flex " aria-current="page" href="<?php echo e(route("demandes.index")); ?>">  <p style="margin-left:10px ;color:white ">Demandes</p>   
                                  </a>
                            </li>
                                <li class="nav-item dropdown">
                                  <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false" style="margin-left:10px;color:white "> Autre
                                  </a>
                                  <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                    <li><a class="dropdown-item" href="<?php echo e(route('utilisateurs.index')); ?>">Utilisateurs</a></li>
                                    <li><a class="dropdown-item" href="<?php echo e(route("emplacements.index")); ?>">Emplacements</a></li>
                                        <li><a class="dropdown-item" href="<?php echo e(route("personnes.index")); ?>"> Personnels</a></li>
                                        <li><a class="dropdown-item" href="<?php echo e(route('salles.index')); ?>">Salles</a></li>
                                    <li><a class="dropdown-item" href="<?php echo e(route('unites.index')); ?>">Unités</a></li>
                                  </ul>
                                </li>
                                <li class="nav-item dropdown" id="notf">
                                  
                                </li>
                                <?php else: ?>
                                <li class="nav-item dropdown">
                                  <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false" style="margin-left:10px;color:white ">   Catégories 
                                  </a>
                                  <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                    <?php $__currentLoopData = App\Models\Categorie::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                       <li><a class="dropdown-item" href="<?php echo e(route('articles.index',['id'=>$cat->id])); ?>"><?php echo e($cat->categorie); ?></a></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                   
                                  </ul>
                                </li> 
                                <li class="nav-item ">
                                    <a class="nav-link active" style="display:flex " aria-current="page" href="<?php echo e(route("articles.index")); ?>">  <p style="margin-left:10px ;color:white ">Matériels</p>   
                                      </a>
                                </li>
                                <?php if(Auth::user()): ?>
                                <li class="nav-item ">
                                  <a class="nav-link active" style="display:flex " aria-current="page" href="<?php echo e(route("demandes.index")); ?>">  <p style="margin-left:10px ;color:white ">Demandes</p>   
                                    </a>
                              </li>
                                <?php endif; ?>
                              
                             <?php endif; ?>
                             
                          
                        </ul>
                        <!-- Right Side Of Navbar -->
                        <ul class="navbar-nav ms-auto">
                            <!-- Authentication Links -->
                            <?php if(auth()->guard()->guest()): ?>
                                <?php if(Route::has('login')): ?>
                                    <li class="nav-item">
                                        <a class="nav-link" href="<?php echo e(route('login')); ?>" style="margin-left:10px "><?php echo e(__('Login')); ?></a>
                                    </li>
                                <?php endif; ?>
            
                                <?php if(Route::has('register')): ?>
                                    <li class="nav-item">
                                        <a class="nav-link" href="<?php echo e(route('register')); ?>" style="margin-left:10px "><?php echo e(__('Register')); ?></a>
                                    </li>
                                <?php endif; ?>
                            <?php else: ?>
                                <li class="nav-item dropdown">
                                    <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                        <?php echo e(Auth::user()->name); ?>

                                    </a>
            
                                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                                        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                           onclick="event.preventDefault();
                                                         document.getElementById('logout-form').submit();">
                                            <?php echo e(__('Logout')); ?>

                                        </a>
            
                                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                            <?php echo csrf_field(); ?>
                                        </form>
                                    </div>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
            </nav>
          
              <main class="container"  >
                <?php echo $__env->yieldContent('content'); ?>
              </main>
    </div>
</body>
</html>
<script>
 window.onload=resiz;
 function resiz() {
  if(window.innerWidth<700){  
  document.getElementById('notf').innerHTML=`<a class="nav-link active"   aria-current="page" href="<?php echo e(route("notifications.index")); ?>">  <p style="margin-left:10px ;color:white ">Notifications</p>   
                                      </a>`;
 
     }
     else  
     document.getElementById('notf').innerHTML= `<a id="notf" class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false" style="margin-left:10px ;color:white">
                                                
      <?php if(auth()->user()): ?>
                                               <?php if( count(auth()->user()->unreadnotifications)!=0 ): ?>
                                                  <span style="border-radius:40%;padding-left:5px;padding-right:5px;font-size:13px;color:white;background-color:red;position:relative;left:32px;top:-12px"><?php echo e(count(auth()->user()->unreadnotifications)); ?></span>
                                                <?php endif; ?>
                                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-bell-fill" viewBox="0 0 16 16">
                                                  <path d="M8 16a2 2 0 0 0 2-2H6a2 2 0 0 0 2 2zm.995-14.901a1 1 0 1 0-1.99 0A5.002 5.002 0 0 0 3 6c0 1.098-.5 6-2 7h14c-1.5-1-2-5.902-2-7 0-2.42-1.72-4.44-4.005-4.901z"/>
                                                </svg> 
                                  </a><ul class="dropdown-menu" aria-labelledby="navbarDropdown" id="not">
                                  <?php $__currentLoopData = auth()->user()->notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <?php if($n->read_at==null): ?>
                                  <?php if(isset($n->data['article']) ): ?>
                                                  <li style="background-color: rgb(171, 171, 189)"><form action="<?php echo e(route("notifications.update",['notification'=>$n->id])); ?>" method="post"><?php echo csrf_field(); ?> <?php echo method_field("put"); ?>
                                                    <a class="dropdown-item" href="<?php echo e(route('articles.show',['article'=>$n->data['article_id']])); ?>"> <?php echo e("L'article ".$n->data['article']." a une quantité de ".$n->data['qteStock']); ?> | <button>ok</button> </a></form></li>
                                                <?php else: ?>
                                                  <li style="background-color: rgb(171, 171, 189)"><form action="<?php echo e(route("notifications.update",['notification'=>$n->id])); ?>" method="post"><?php echo csrf_field(); ?> <?php echo method_field("put"); ?>
                                                    <a class="dropdown-item" href="<?php echo e(route('demandes.show',['demande'=>$n->data['demande_id']])); ?>"> 
                                                    <?php if( isset($n->data['demandeurS']) ): ?>
                                                    <?php echo e(User::withTrashed()->where("id",$n->data['user'])->get()[0]->name."  a demander  L'article ".Article::withTrashed()->where("id",$n->data['articleD'])->get()[0]->designation." pour  la salle ".Salle::find($n->data['demandeurS'])->nom); ?> 
                                                    <?php else: ?>
                                                    <?php echo e(User::withTrashed()->where("id",$n->data['user'])->get()[0]->name."  a demander  L'article ".Article::withTrashed()->where("id",$n->data['articleD'])->get()[0]->designation." pour  le personnel ".Personne::find($n->data['demandeurP'])->nom); ?> 
                                                    <?php endif; ?>
                                                  | <button>ok</button></form> </a></li>
                                                <?php endif; ?>
                                  <?php else: ?>
                                                <?php if(isset($n->data['article']) ): ?>
                                                  <li > <a class="dropdown-item" href="<?php echo e(route('articles.show',['article'=>$n->data['article_id']])); ?>"> <?php echo e("L'article ".$n->data['article']." a une quantité de ".$n->data['qteStock']); ?> </a></li>
                                                <?php else: ?>
                                                  <li >
                                                    <a class="dropdown-item" href="<?php echo e(route('demandes.show',['demande'=>$n->data['demande_id']])); ?>"> 
                                                      <?php if( isset($n->data['demandeurS']) ): ?>
                                                      <?php echo e(User::withTrashed()->where("id",$n->data['user'])->get()[0]->name."  a demander  L'article ".Article::find($n->data['articleD'])->designation." pour  la salle ".Salle::find($n->data['demandeurS'])->nom); ?> 
                                                      <?php else: ?>
                                                      <?php echo e(User::withTrashed()->where("id",$n->data['user'])->get()[0]->name."  a demander  L'article ".Article::find($n->data['articleD'])->designation." pour  le personnel ".Personne::find($n->data['demandeurP'])->nom); ?> 
                                                      <?php endif; ?> 
                                                    </a>
                                                  </li>
                                              <?php endif; ?>
                                  <?php endif; ?>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              <?php endif; ?>
                                  </ul>`}
    //  document.addEventListener("change",resiz() );
    
</script>

<?php /**PATH C:\Users\Akay\Documents\insa\gestionStock\resources\views/layouts/app.blade.php ENDPATH**/ ?>