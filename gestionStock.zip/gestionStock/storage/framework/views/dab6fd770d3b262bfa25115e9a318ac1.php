
 <?php $__env->startSection('content'); ?>
 <br>
 <u><h3>Liste des mouvements</h3></u>
 <hr>
<br>
 <table class="table table-striped table-hover" border="1" width="60%" align="center">
<tr><th>Désignation</th><th>Quantité global</th> <th>Quantité Entrer</th><th>Date Entrer</th><th>Quantité sortie</th><th>Date sortie</th><th>Quantité final</th> </tr> 
<?php $__currentLoopData = $mouvements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
<tr><td><?php echo e($aff->articles()->withTrashed()->get()[0]->designation); ?></td><td> <?php echo e($aff->qteGlobal); ?></td> <td><?php echo e($aff['QEntrer']); ?></td><td><?php echo e($aff['dateEntrer']); ?></td><td> <?php echo e($aff->qteSortie); ?></td> <td> <?php echo e($aff->dateSortie); ?></td> <td> <?php echo e($aff->articles()->withTrashed()->get()[0]->qteStock); ?></td> 
</tr>
    
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<p><?php echo e($mouvements->links()); ?></p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Akay\Documents\insa\gestionStock\resources\views/mouvement.blade.php ENDPATH**/ ?>