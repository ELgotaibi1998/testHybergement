
<?php $__env->startSection("content"); ?>
<div class="container">
 <u><h1>  Radiat</h1> </u>
 <div style="display: flex;flex-wrap:wrap">
    <?php $__currentLoopData = $radiats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <div class="card" style="width: 18rem;margin:10px">
      <div class="card-header">Désignation : <?php echo e($d->articles()->withTrashed()->get()[0]->designation); ?></div>
    <ul class="list-group list-group-flush">
        <li class="list-group-item">Date de radiat : <?php echo e($d->dateRadiat); ?></li>
      <li class="list-group-item">Motif : <?php echo e($d->motif); ?> </li>
    </ul>
  </div> 
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 </div>
</div>
   
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Akay\Documents\insa\gestionStock\resources\views/radiat/index.blade.php ENDPATH**/ ?>