
 <?php $__env->startSection('content'); ?>
 <br>
 <u><h1>Ajouter un Salle</h1></u><br>
<table class="table">
      
<form action="<?php echo e(route('salles.store')); ?>" method="post">
    <?php echo csrf_field(); ?>
       <tr><td>Nom : </td> <td><input type="test" name="nom"></td> </tr>
       <tr><td>Service : </td> <td><input type="text" name="service"></td> </tr>
      
      
<tr> <td><a class="btn btn-secondary" href="<?php echo e(route('salles.index')); ?>">Retour</a><br><br> <td></td>   <td> <button  class="btn btn-success"> Enregister</button></td></tr>

</form>

    </table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Akay\Documents\insa\gestionStock\resources\views/Salle/create.blade.php ENDPATH**/ ?>