<h1>Bonjour <?php echo e(Auth::user()->name); ?></h1>
<p>Votre demande a été accepter 
    <br>
    l'article <?php echo e($mail->demandes()->withTrashed()->get()[0]->articles()->withTrashed()->get()[0]->designation); ?>   sera affecter le <?php echo e($mail->dateReception); ?> <br>
    l'emergent de reception :  <?php echo e($mail->emergentReception); ?>

</p>
<a href="http://127.0.0.1:8000">Consulté le site </a><?php /**PATH C:\Users\Akay\Documents\insa\gestionStock\resources\views/emails/email.blade.php ENDPATH**/ ?>