
<?php $__env->startSection("content"); ?>
<div >
 <u><h1>Modifier Salle</h1></u>
 <form action="<?php echo e(route('salles.update',['salle'=>$sal['id']])); ?>" method="post">
    <?php echo method_field("put"); ?>
    <?php echo csrf_field(); ?>
   <table class="table">
   <tr><td>Nom : </td> <td><input type="text" name="nom" value="<?php echo e($sal->nom); ?>"></td> </tr>
       <tr><td>Service : </td> <td><input type="text" name="service" value="<?php echo e($sal->service); ?>"></td> </tr>
<tr> <td><a class="btn btn-secondary" href="<?php echo e(route('salles.index')); ?>">Retour</a>  </td> 
  <td> <button  class="btn btn-success"> Modifier</button></td></tr>
</table>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Akay\Documents\insa\gestionStock\resources\views/salle/edit.blade.php ENDPATH**/ ?>