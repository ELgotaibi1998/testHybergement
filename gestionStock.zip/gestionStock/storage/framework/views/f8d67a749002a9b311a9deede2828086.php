
<?php $__env->startSection("content"); ?>
<br>
 <u><h1>Ajouter un Bon de commande</h1></u>

 <hr>
 <br>
          <div class="card"  >   <form action="<?php echo e(route('marches.store')); ?>" method="post"> <?php echo csrf_field(); ?>
        <div class="card-body">
          <table>
            <tr>
              <td> Fournisseur :</td><td><select name="fournisseur" id="">
            <?php $__currentLoopData = $fournisseurs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($f->id); ?>"><?php echo e($f->nom); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select> </td>
            </tr>
            <tr>
              <td> Numéro du marché :  </td><td><input type="text" name="numMarche"></td>
            </tr>
            <tr>
              <td>  Date marché : </td><td> <input type="datetime-local" name="dateCmd">  </td>
            </tr>
          </table>
        </div>
        <div class="card-footer" style="text-align: center">
        <input type="submit" value="Ajouter" class="btn btn-success">
        </div> </form>
      </div>
</div>
<?php $__env->stopSection(); ?>
<style>
  input{
    width: 100%
  }
  select{
    width: 100%
  }
</style>
<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Akay\Documents\insa\gestionStock\resources\views/marches/create.blade.php ENDPATH**/ ?>