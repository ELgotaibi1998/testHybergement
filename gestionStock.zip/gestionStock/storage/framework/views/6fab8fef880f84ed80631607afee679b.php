
<?php $__env->startSection("content"); ?>
<br>
<a href="<?php echo e(route('marches.create')); ?>"><button  class="btn btn-primary">Ajouter</button></a>
<br>
 <u> <h3  >Marché</h3></u><br>
<hr>
<?php $__currentLoopData = $marches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card"  style="padding-left: 2%;padding-right: 2%;margin-bottom: 10px;"> <br>
      <h5 class="card-title">Numéro <?php echo e($b->numMarche); ?></h5>
      <p>le <?php echo e($b->dateCmd); ?></p>
      <p>le  Fournisseur : <?php echo e($b->fournisseurs->nom); ?></p>
                        <div class="card-body">
                                        <table class="table table-striped table-hover">
                                        <tr><th>Article</th><th>Qte</th><th>PT</th><th>TVA</th></tr>
                                        <?php $__currentLoopData = $b->factures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr><td><?php echo e($f->articles()->withTrashed()->get()[0]->designation); ?></td><td><?php echo e($f->qte); ?></td><td><?php echo e($f->prixT); ?></td><td><?php echo e($f->tva." %"); ?></td></tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                      
                                        </table>
                        </div>
                        <div class="card-footer"> <a href="<?php echo e(route('marches.show',['march'=>$b->id])); ?>" class="btn btn-primary"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-eye" viewBox="0 0 16 16">
                          <path d="M16 8s-3-5.5-8-5.5S0 8 0 8s3 5.5 8 5.5S16 8 16 8zM1.173 8a13.133 13.133 0 0 1 1.66-2.043C4.12 4.668 5.88 3.5 8 3.5c2.12 0 3.879 1.168 5.168 2.457A13.133 13.133 0 0 1 14.828 8c-.058.087-.122.183-.195.288-.335.48-.83 1.12-1.465 1.755C11.879 11.332 10.119 12.5 8 12.5c-2.12 0-3.879-1.168-5.168-2.457A13.134 13.134 0 0 1 1.172 8z"/>
                          <path d="M8 5.5a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5zM4.5 8a3.5 3.5 0 1 1 7 0 3.5 3.5 0 0 1-7 0z"/>
                        </svg></a>  </div>
    </div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<p><?php echo e($marches->links()); ?></p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Akay\Documents\insa\gestionStock\resources\views/marches/index.blade.php ENDPATH**/ ?>