
<?php $__env->startSection("content"); ?>
<br>
 <h1>Ajouter un Matériels</h1>
       <hr >
       <form action="<?php echo e(route("articles.store")); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
          <table class="table "  >
            <tr><td>Catégorie</td> <td><select name="categorie"  required>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($cat->id); ?>" <?php if(old("categorie")==$cat->id): ?>
                selected
              <?php endif; ?>><?php echo e($cat->categorie); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select></td> </tr>
          <tr><td>Emplacement</td> <td><select name="emplacement"  required>
            <?php $__currentLoopData = $emplacements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lieu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($lieu->id); ?>" <?php if(old("emplacement")==$lieu->id): ?>
                selected
              <?php endif; ?>><?php echo e($lieu->emplacement); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select></td> </tr>
          <tr><td>Reference</td> <td><input type="text" name="reference" value="<?php echo e(old("reference")); ?>" required><p class="text-danger"> <?php $__errorArgs = ['reference'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <?php echo e($message); ?> <br><a href="<?php echo e('/getRef?reference='.old('reference')); ?>">Voir l'article</a>

          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p></td> </tr>
          <tr><td>Designation</td> <td><input type="text" name="designation" value="<?php echo e(old("designation")); ?>" required></td> </tr>
          <tr><td>Prix Unitaire</td> <td><input type="text" name="pu" value="<?php echo e(old("pu")); ?>" required>  <p class="text-danger"><?php $__errorArgs = ["pu"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <?php echo e($message); ?>

          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p> </td> </tr>
          <tr><td>Date d'ajout</td> <td><input type="datetime-local" name="dateAjout" required value="<?php echo e(old('dateAjout')); ?>"></td> </tr>
          <tr><td>Stock minimal</td> <td><input type="text" name="stockMin" value="<?php echo e(old("stockMin")); ?>" required/>   <p class="text-danger"><?php $__errorArgs = ["stockMin"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <?php echo e($message); ?>

          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p> 
           </td> </tr>
           <tr><td>Stock Max</td> <td><input type="text" name="stockMax" value="<?php echo e(old("stockMax")); ?>" required/>   <p class="text-danger"><?php $__errorArgs = ["stockMax"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <?php echo e($message); ?>

          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p> 
           </td> </tr>
           <tr><td>Stock d'alert</td> <td><input type="text" name="stockAlert" value="<?php echo e(old("stockAlert")); ?>" required/>   <p class="text-danger"><?php $__errorArgs = ["stockAlert"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <?php echo e($message); ?>

          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p> 
           </td> </tr>
           <tr><td>Stock de sécurité</td> <td><input type="text" name="stockSecurite" value="<?php echo e(old("stockSecurite")); ?>" required/>   <p class="text-danger"><?php $__errorArgs = ["stockSecurite"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <?php echo e($message); ?>

          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p> 
           </td> </tr>
          <tr><td>Quantité</td> <td><input type="text" name="qte" value="<?php echo e(old("qte")); ?>" required>   <p class="text-danger"><?php $__errorArgs = ["qte"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <?php echo e($message); ?>

          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>  </td> </tr>
          <tr><td>Unité</td> <td><select name="unite" required >
            <?php $__currentLoopData = $unites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unite): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($unite->id); ?>" <?php if(old("unite")==$unite->id): ?>
                selected
              <?php endif; ?>><?php echo e($unite->unite); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select></td> </tr>
           <tr><td>Observations</td><td ><textarea name="observation"  rows="4"><?php echo e(old("observation")); ?></textarea></td></tr>
            <tr><td>Images </td><td><input type="file" name="images[]" multiple width="100%" /></td></tr>
            <tr ><td><a href="<?php echo e(route('articles.index')); ?>" class="btn btn-secondary">Retour</a></td><td><input type="submit"  class="btn btn-success" value="Ajouter"></td> </tr>
          </table>
        </form>
</div>
   
    
<?php $__env->stopSection(); ?>
<style>
  input{
    width: 100%
  }
  select{
    width: 100%
  }
  textarea{
    width: 100%;
  }
  
</style>
<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Akay\Documents\insa\gestionStock\resources\views/articles/create.blade.php ENDPATH**/ ?>